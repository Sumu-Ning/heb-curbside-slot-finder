Installation

Turn on Chrome developer mode and load the unpacked extension from the heb-curbside-slot-finder folder (https://webkul.com/blog/how-to-install-the-unpacked-extension-in-chrome/).

Fill in the address, and update other parameters if needed. Click <Query> button to see the curbside slot availability.

